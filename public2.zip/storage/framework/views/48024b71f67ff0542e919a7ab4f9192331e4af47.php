<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $singles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
  <div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-8">
      <div class="jdl page-header"><?php echo e($single->title); ?></div>
      <div class="isi">
        <?php echo $single->description; ?>

        <!--<?php echo $single->description; ?> <a href='.url("/".$post->slug). -->
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      <hr>
    </div>
    <div class="col-md-2"></div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>