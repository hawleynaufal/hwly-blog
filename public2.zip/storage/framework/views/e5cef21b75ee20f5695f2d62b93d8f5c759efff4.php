<?php $__env->startSection('title','Blog Anu'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-8 jumbotron">
      <h1>Blog Gue</h1>
    <p><i>The Larges Web of family's stories </i></p>
    </div>
    <div class="col-md-2"></div>
  </div>
<?php if(Auth::check()): ?>
<h4><b><a href="/blog">Manage Post</a></b></h4>
<?php endif; ?>

  <?php $__currentLoopData = $shows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
  <div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-8">

      <div class="jdl page-header"><a href="../post/<?php echo e($show->slug); ?>"><?php echo e($show->title); ?></a></div>

      <div class="isi">
        <?php echo str_limit($show->description, $limit= 300 , $end= '...... '); ?>

        <!--<?php echo $show->description; ?> <a href='.url("/".$post->slug). -->
      </div>
      <p>url: <?php echo e(url($show -> slug)); ?></p>
      <hr>
    </div>
    <div class="col-md-2"></div>
  </div>


      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
<?php echo e($shows->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>